from distutils.core import setup, Extension
from Cython.Build import cythonize
import numpy

setup(
    ext_modules=[
        Extension("compute_overlap", ["compute_overlap.c"],
                  include_dirs=[numpy.get_include()]),
    ],
)


setup(
  name = 'compute_overlap app',
  ext_modules = cythonize("compute_overlap.pyx"),
)